package MyBasicPackage1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BasicSelenium1 {
	WebDriver driver;

	public void setBrowser(String browser, String url) {
		String currDirectory = System.getProperty("user.dir");
		if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", currDirectory+"\\Driver\\chromedriver.exe");
			driver= new ChromeDriver();
		} else if (browser.equals ("firefox")){
			System.setProperty("webdriver.gecko.driver", currDirectory+"\\Driver\\geckodriver.exe");
			driver= new FirefoxDriver();
			}
		else if (browser.equals ("ie")){
			System.setProperty("webdriver.ie.driver", currDirectory+"\\Driver\\IEDriverServer.exe");
			driver= new InternetExplorerDriver();
			}
		else if (browser.equals ("edge")){
			//System.setProperty("webdriver.ie.driver", currDirectory+"\\Driver\\IEDriverServer.exe");
			driver= new EdgeDriver();
			}else {
				System.out.println("Seems like no valid browser is provided");
				System.exit(0);
			}
		if (url !="") 
			driver.get(url);
		else
			driver.get("about:blanlk");
		
	}
	
	public  void findElement() {
	
		//driver.findElement(By.id("))"
	
		/*driver.findElement(By.id("email")).sendKeys("Narinder.gupta@gmail.com");//find element by id
		driver.findElement(By.name("pass")).sendKeys("Stamford2020?");//find element by name
		driver.findElement(By.id("u_0_b")).click(); //find element by 
		driver.close();*/
		//driver.findElement(By.linkText(linkText))
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("narinder.gupta@gmail.com");
		driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("Naresh@simla57");
		driver.findElement(By.xpath("//button[@name='login']")).click();//find element by link  xpath
		driver.findElement(By.linkText("linkForgot Password?Text")).click();  //find element by link  text
		
		
	}
	
	
	public static void main(String[] args) {
		
		System.out.println("MyFirstJava Program");
	     
		// TODO Auto-generated method stub
		BasicSelenium1 obj = new BasicSelenium1();
		obj.setBrowser("chrome","https://www.facebook.com");
		obj.findElement();
		

		
	
	
		/*obj.setBrowser ("firefox","https://www.facebook.com");
		obj.findElement();
	   */
		//obj.setBrowser("ie","http://narinderguptaphotography.com");
		//obj.driver.close();
	}

}
